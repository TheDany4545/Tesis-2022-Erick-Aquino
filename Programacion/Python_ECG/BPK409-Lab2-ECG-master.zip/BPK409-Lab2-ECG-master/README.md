# Lab 2 - ECG
Please refer to the [Lab Manual 2 - ECG](https://docs.google.com/document/d/e/2PACX-1vSOCHCjlX8OgWBBw-9TD-SZMikOhjnY5c3PdTVODe1hS5QOUEa1IZiLfZUne3qlMQ2jJGJ56BPspiV-/pub) webpage for more information. 

Please refer to the [Lab Overview Manual](https://docs.google.com/document/d/e/2PACX-1vTr1zOyrUedA1yx76olfDe5jn88miCNb3EJcC3INmy8nDmbJ8N5Y0B30EBoOunsWbA2DGOVWpgJzIs9/pub) webpage for some general information about the course. 

This work is licensed under a [Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.](https://creativecommons.org/licenses/by-nc-sa/4.0/)
